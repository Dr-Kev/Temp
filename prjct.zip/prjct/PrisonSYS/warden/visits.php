
<?php 
include'headr.php';
?> 

    <div id="wrapper">
        <div class="sectin">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="tagline-message">
                            <img src="inc/images/banner.jpg" style="max-width: 100%">
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end section -->

        <section class="section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="text-widget">
                            <h3 style="text-align: left; margin-top: -80px; font-size: 18px; font-family:'Courier New', Courier, monospace;">
                            Visitation Forms
                            </h3>

                            <table class="table table-hover">
                          <thead>
                            <tr>
                              <th scope="col">#</th>
                              <th scope="col">Time</th>
                              <th scope="col">Visitor</th>
                              <th scope="col">Inmate</th>
                              <th scope="col">ID Number</th>
                            </tr>
                          </thead>

                          <?php
                          if ($conn){
                            $data =  get('visits', $conn);
                          } else die('Could Not Connect');
                          ?> 
                          <?php if ($data) : 
                             $i=1; 
                             foreach ($data as $info) { ?>
                          <tbody>
                            <tr>
                              <th scope="row"><?php echo $i;  $i++;?></th>
                              <td> <?php echo $info['time'];?></td>
                              <td> <?php echo $info['visitor'];?></td>
                              <td> <?php echo $info['inmate'];?></td>
                              <td> <?php echo $info['id_number'];?></td>
                            </tr>
                          </tbody>

                            <?php } endif; ?>

                        </table>
                        </div><!-- end widget -->
                    </div><!-- end col-lg-6 -->
                </div><!-- end row -->
            </div><!-- end container -->
        </section>

        

<?php 
include'footr.php';
?> 
