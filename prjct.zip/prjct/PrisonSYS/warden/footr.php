      
      <div class="section copyrights">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-3">
                        <img src="inc/images/gok.gif" alt="" style="height: 50px; width: 50px;margin-left: 20px;">
                    </div>
                    <div class="col-lg-9 col-md-9 text-right">
                        <div class="cop-links">
                            <ul class="list-inline">
                                <li>&copy; 2019 Kenya Prison's Info System | Designer: <a href="#">Dr~K</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- end wrapper -->

    <!-- jQuery Files -->

    <script type="text/javascript">
      $('select').selectpicker();
      
        $(function() {
          $('.dates #usr1').datepicker({
            'format': 'yyyy-mm-dd',
            'autoclose': true
          });
        });

        function triggerClick(){
            document.querySelector('#imag').click();
          }

          function displayImage(e){
            if (e.files[0]){
              var reader = new FileReader();

              reader.onload = function(e){
                document.querySelector('#imagDisplay').setAttribute('src', e.target.result);
              }
              reader.readAsDataURL(e.files[0]);
            }
          }
    </script>

<!-- ############################################################ -->

    <script type="text/javascript">
    $(document).ready(function() {
      $('.workbtn').on('click', function() {
        $('#editmodal').modal('show');

        $tr = $(this).closest('tr');

        var data = $tr.children("td").map(function () {
          return $(this).text();
        }).get();
        console.log(data);

        $('#update_id').val(data[0]);
        $('#Wtitle').val(data[1]);
        $('#Wdesc').val(data[2]);
        $('#Winm').val(data[3]);
        $('#Wperf').val(data[4]);
      });
    });
      </script>

  <!-- ######################################################## -->

      <script type="text/javascript">
    $(document).ready(function() {
      $('.medbtn').on('click', function() {
        $('#med_modal').modal('show');

        $tr = $(this).closest('tr');

        var data = $tr.children("td").map(function () {
          return $(this).text();
        }).get();
        console.log(data);

        $('#update_id').val(data[0]);
        $('#Mdoc').val(data[1]);
        $('#MName').val(data[2]);
        $('#day').val(data[3]);
        $('#Mdis').val(data[4]);        
        $('#Mrec').val(data[5]);
      });
    });
      </script>
</body>
</html>