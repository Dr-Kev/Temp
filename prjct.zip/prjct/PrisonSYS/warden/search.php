
<?php 
include'headr.php';
?> 

    <div id="wrapper">

        <div class="sectn">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="tagline-message">
                                <img src="inc/images/banner.jpg" style="max-width: 100%">
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end section -->

        <section class="section">
            <div class="container">
                <div class="row">
                    <!-- Search form -->
                            <div class="col-lg-3 col-md-12"></div>

                            <?php
                              $output  = "";
                              $output2 = "";
                              if (isset($_POST['such'])){
                                $output = $_POST['search'];

                $runn = $conn->prepare('SELECT * FROM inmates WHERE fname LIKE :first or sname LIKE :second');
                        $runn->execute(array('first' => $output . '%',
                                             'second' => $output . '%' ));
                                 while ($result = $runn->fetch()){
                                                  $first = $result['fname'];
                                                  $second= $result['sname'];

                                            $output2 .= '<div>'.$first.' '.$second.'</div>';
                              
                              }
                                }
                            ?>
                            <form method="POST" action="search.php">
                            <div class="col-lg-6 active-cyan-3 active-cyan-4 mb-4">
                              <input class="form-control" type="text" name="search" placeholder="Search First Or Last Name" aria-label="Search" style=""><i class="glyphicon glyphicon-search" style="position: absolute;  padding: 10px; cursor: pointer; pointer-events: none; right: 20px;"></i>
                              <button type="submit" name="such" style="display: none;"></button>
                            <?php print($output2);?>
                            </div>
                            </form>

                            <div class="col-lg-3 col-md-12"></div>

                            <div class="margin-block"></div>
                            <div class="margin-block"></div>

                    <div class="col-lg-12 col-md-12">
                        <div class="text-widget">
                            <h3 style="text-align: center; font-style: italic; font-family: 'Courier New', Courier, monospace;">Search Results</h3>
                            <?php
                              $output  = "";
                              $row  = "";
                              $num = "";
                              if (isset($_POST['such'])){
                                $output = $_POST['search'];

                                $row = block('SELECT * FROM inmates WHERE fname LIKE :first or sname LIKE :second',
                                      array('first' => $output . '%',
                                            'second' => $output . '%' ),$conn);
                            $num = count($row);
                            }


                            if ($num == 1 && $row ) :
                             foreach ($row as $info) {
                            ?>

                            <div class="col-md-3 text-center">
                            <label for="imag">Inmate Photo</label>
                            <img src="img_upload/<?php echo($info['img_name']);?>" style="max-width: 100%; border-radius: 50%; display: block;" id="imagDisplay">
                             </div><!-- end col -->

                            <div class="col-md-9"> 
                            <div class="container">
                               </br>
                                     <form class="form-horizontal">
                                         <div class="form-group">
                                            <label class="control-label col-xs-3" for="firstName">First Name:</label>
                                             <div class="col-xs-9">
                                <input type="text" class="form-control" id="firstName" placeholder="First Name" value="<?php echo $info['fname'];?>">
                                         </div>
                                         </div>

                                         <div class="form-group">
                                             <label class="control-label col-xs-3" for="lastName">Last Name:</label>
                                             <div class="col-xs-9">
                    <input type="text" class="form-control" id="lastName" value="<?php echo $info['sname'];?>">
                                         </div>
                                          </div>

                            <div class="form-group">
                              <label class="control-label col-xs-3" for="b_date">D.O.B:</label>
                                <div class="col-xs-4">
                    <input type="text" class="form-control" id="b_date" value="<?php echo $info['birth_date'];?>">
                                </div>
                            </div>

                            <div class="form-group">
                              <label class="control-label col-xs-3" for="a_date">Confined On:</label>
                                <div class="col-xs-4">
                <input type="text" class="form-control" id="a_date" value="<?php echo $info['admission_day'];?>">
                                </div>
                            </div>

                              <div class="form-group">
                                   <label class="control-label col-xs-3" for="idNumber">ID Number:</label>
                                   <div class="col-xs-9">
                                    <input type="text" class="form-control" name="idNum" id="idNumber" value="<?php echo $info['id_number'];?>">
                                   </div>
                              </div>

                            <div class="form-group">
                                <label class="control-label col-xs-3" for="sentc">Sentence:</label>
                                <div class="col-xs-3">
                                    <input type="text" class="form-control" name="cent" id="sentc" value="<?php echo $info['sentence'];?>">
                                </div>

                                   <label class="control-label col-xs-3" for="phoneNumber">Cell No:</label>
                                   <div class="col-xs-3">
                                    <input type="text" class="form-control" name="cell" id="cellNumber" value="<?php echo $info['cell_No'];?>">
                                   </div>
                              </div>

                            <div class="form-group">
                                <label class="control-label col-xs-3" for="offence">Offence Committed:</label>
                                <div class="col-xs-9">
                                    <input type="text" class="form-control" name="cell" id="cellNumber" value="<?php echo $info['offence'];?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="control-label col-xs-3" for="blocks">Resident Block:</label>
                                <div class="col-xs-6">
                                    <input type="text" class="form-control" name="blocks" id="blocks" value="Block <?php echo $info['block'];?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="control-label col-xs-3">Gender:</label>
                                <div class="col-xs-6">
                            <input type="text" class="form-control" id="gend" value="<?php echo $info['gender'];?>">
                                </div>
                            </div>

                                     <div class="form-group">
                                          <div class="col-xs-offset-3 col-xs-9">
                                          <!-- <input type="submit" class="btn btn-primary" value="Print" style="background-color: #4CAF50; color: white; cursor: pointer; border-radius: 20px;"> -->
                                          
                                          </div>
                                     </div>
                                     </form>
                               </div>
                            </div>

                            <?php } endif; ?>

                            <div class="clearfix"></div>     
                        </div><!-- end widget -->
                    </div><!-- end col-lg-6 -->
                </div><!-- end row -->
            </div><!-- end container -->
        </section>
                    <div class="margin-block"></div>


<?php 
include'footr.php';
?> 