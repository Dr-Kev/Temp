
<?php 
include'headr.php';
if (isset($_POST['upload'])){

  $nam = $_POST['name'];
  $pas = $_POST['pass'];
  $cat = $_POST['cat'];

   registry("INSERT INTO logins (username,password,category) values (:nm,:pss,:ct)",
               array('nm' => $nam,
                     'pss'=> $pas,
                     'ct' => $cat) ,$conn);
}
?>
    <div id="wrapper">
        <div class="sectin">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="tagline-message">
                            <img src="inc/images/banner.jpg" style="max-width: 100%">
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end section -->

        <section class="section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="text-widget">
                            <h3 style="text-align: left; margin-top: -80px; font-size: 18px; font-family:'Courier New', Courier, monospace;">
                            User Login Credentials:
                            </h3>
                            <div>
                              <a href="#" data-toggle="modal" data-target="#modalnew">
                              <input type="button" value="New User" style="background-color: #4CAF50; color: white; cursor: pointer; border-radius: 20px;">
                              </a>
                            </div>

                            <div class="margin-block"></div>

                        <div class="table-responsive">
                                    <table class="table table-hover">
                                    <thead style="background-color: darkgrey;">
                                      <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Usernames</th>
                                        <th scope="col">Passwords</th>
                                        <th scope="col">Category</th>
                                        <th scope="col">Change</th>
                                      </tr>
                                    </thead>
                          <?php
                          if ($conn){
                            $data =  get('logins', $conn);
                          }
                          ?> 

                          <?php 

                             $i=1;
                             if ($data) : 
                             // $count = $data->rowCount(); 
                             foreach ($data as $info) {?>
                                    <tbody>
                                      <tr>
                                      <th scope="row"> <?php echo $i; $i++;?></th>
                                      <td style="display: none;"> <?php echo $info['id'];?></td>
                                      <td> <?php echo $info['username'];?></td>
                                      <td> <?php echo $info['password'];?></td>
                                      <td> <?php echo $info['category']; ?></td>
                                      <td>
                                      <a href="#"  data-toggle="modal">
                                        <input type="button" value="Review" class="workbtn" style="background-color: #4CAF50; color: white; cursor: pointer; border-radius: 20px;">
                                        </a>
                                      </td>
                                    </tr>
                                        
                                    </tbody>

                            <?php } endif; ?>

                                  </table>
                                </div>
                        </div><!-- end widget -->
                    </div><!-- end col-lg-6 -->
                </div><!-- end row -->
            </div><!-- end container -->
        </section>
                    <div class="margin-block"></div>




      <!-- Modal New-->
<div id="modalnew" class="modal fade" role="dialog" style="max-width: 100%;">
  <div class="modal-dialog" style="margin-top: 50px;">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="text-align: center; font-style: italic; font-family: 'Courier New', Courier, monospace;">Work Details</h4>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" action="login_creds.php" method="POST" enctype="multipart/form-data">
          <div class="container">                                          
              <div class="form-group">
               <label class="control-label col-xs-4" for="name">Username:</label>
                    <div class="col-xs-8">
                      <input type="text" class="form-control" name="name" id="name" placeholder="Username">
                    </div>
              </div>

              <div class="form-group">
                <label class="control-label col-xs-4" for="pass">Password:</label>
                <div class="col-xs-8">
                      <input type="text" class="form-control" name="pass" id="pass" placeholder="Password">
                </div>
              </div>     

              <div class="form-group">
                <label class="control-label col-xs-4" for="cat">User Category:</label>
                <div class="col-xs-8">
                    <input type="text" class="form-control" name="cat" id="cat" placeholder="gurad or warden(Admin)">
                </div>
              </div>

                 <br>
                   <div class="form-group">
                                <div class="col-xs-offset-5 col-xs-9">
                                <input type="submit" name="upload" class="btn btn-primary" value="Submit">
                                </div>
                  </div>

          </div>
        </form>
      </div>
    </div>

  </div>
</div>
  

   <!-- Review Modal -->
<div class="modal fade" id="editmodal" tabindex="-1" role="dialog" aria-hidden="true" style="max-width: 100%;">
  <div class="modal-dialog" style="margin-top: 50px;">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="text-align: center; font-style: italic; font-family: 'Courier New', Courier, monospace;">Edit Details</h4>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" method="POST" action="update.php" enctype="multipart/form-data">
          <div class="container"> 
          
          <input type="hidden" name="update_id" id="update_id">
          
            <div class="form-group">
               <label class="control-label col-xs-3" for="Wtitle">Username:</label>
               <div class="col-xs-9">
                <input type="text" class="form-control" name="Wtitle" id="Wtitle">
               </div>
              </div>
              <div class="form-group">
                <label class="control-label col-xs-3" for="Wdesc">Password:</label>
                <div class="col-xs-9">
                  <input type="text" class="form-control" name="Wdesc" id="Wdesc">
              </div>
            </div>

              <div class="form-group">
               <label class="control-label col-xs-3" for="Winm">User Category:</label>
               <div class="col-xs-9">
                  <input type="text" class="form-control" name="Winm" id="Winm">
               </div>
              </div>
                 <br>
                   <div class="form-group">
                                <div class="col-xs-offset-5 col-xs-9">
                                <input type="submit" name="update_user" class="btn btn-primary" value="Submit">
                                </div>
                  </div>

<!-- <?php // }  ?> -->
          </div>
        </form>
      </div>
    </div>

  </div>
</div>  

<?php 
include'footr.php';
?> 
