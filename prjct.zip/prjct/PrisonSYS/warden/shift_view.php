        <div class="tab-content" id="myTabContent">
                          <?php
                          if ($conn){
                            $data =  get('shift_monday', $conn);
                          }
                          ?> 
                          <?php if ($data) : 
                             foreach ($data as $info) {?>
                          <div class="tab-pane fade" id="nav-monday" role="tabpanel" aria-labelledby="monday-tab">
                            <div class="container">
                                <div class="row">
                                  <p><?php echo $info['date'];?></p>
                                  <br>
                                  <div class="col-6 col-md-3"><p>Officer's Assigned To Gate Duty:</p>
                                    <?php echo $info['gate'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Kitchen Duty:</p>
                                  <?php echo $info['kitchen'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Prison Partrol Duty:</p>
                                  <?php echo $info['partrols'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Night Shift:</p>
                                  <?php echo $info['night'];?></div>
                              </div>
                            </div>
                          </div>
                            <?php } endif; ?>

                            <?php
                          if ($conn){
                            $data =  get('shift_tuesday', $conn);
                          }
                          ?> 
                          <?php if ($data) : 
                             foreach ($data as $info) {?>
                          <div class="tab-pane fade" id="nav-tuesday" role="tabpanel" aria-labelledby="tuesday-tab">
                            <div class="container">
                                <div class="row">
                                  <p><?php echo $info['date'];?></p>
                                  <br>
                                  <div class="col-6 col-md-3"><p>Officer's Assigned To Gate Duty:</p>
                                    <?php echo $info['gate'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Kitchen Duty:</p>
                                  <?php echo $info['kitchen'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Prison Partrol Duty:</p>
                                  <?php echo $info['partrols'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Night Shift:</p>
                                  <?php echo $info['night'];?></div>
                              </div>
                            </div>
                          </div>
                            <?php } endif; ?>

                            <?php
                          if ($conn){
                            $data =  get('shift_wednesday', $conn);
                          }
                          ?> 
                          <?php if ($data) : 
                             foreach ($data as $info) {?>
                      <div class="tab-pane fade" id="nav-wednesday" role="tabpanel" aria-labelledby="wednesday-tab">
                        <div class="container">
                                <div class="row">
                                  <p><?php echo $info['date'];?></p>
                                  <br>
                                  <div class="col-6 col-md-3"><p>Officer's Assigned To Gate Duty:</p>
                                    <?php echo $info['gate'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Kitchen Duty:</p>
                                  <?php echo $info['kitchen'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Prison Partrol Duty:</p>
                                  <?php echo $info['partrols'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Night Shift:</p>
                                  <?php echo $info['night'];?></div>
                              </div>
                            </div>
                          </div>
                            <?php } endif; ?>

                            <?php
                          if ($conn){
                            $data =  get('shift_thursday', $conn);
                          }
                          ?> 
                          <?php if ($data) : 
                             foreach ($data as $info) {?>
                      <div class="tab-pane fade" id="nav-thursday" role="tabpanel" aria-labelledby="thursday-tab">
                        <div class="container">
                                <div class="row">
                                  <p><?php echo $info['date'];?></p>
                                  <br>
                                  <div class="col-6 col-md-3"><p>Officer's Assigned To Gate Duty:</p>
                                    <?php echo $info['gate'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Kitchen Duty:</p>
                                  <?php echo $info['kitchen'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Prison Partrol Duty:</p>
                                  <?php echo $info['partrols'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Night Shift:</p>
                                  <?php echo $info['night'];?></div>
                              </div>
                            </div>
                          </div>
                            <?php } endif; ?>

                            <?php
                          if ($conn){
                            $data =  get('shift_friday', $conn);
                          }
                          ?> 
                          <?php if ($data) : 
                             foreach ($data as $info) {?>
                          <div class="tab-pane fade" id="nav-friday" role="tabpanel" aria-labelledby="friday-tab">
                            <div class="container">
                                <div class="row">
                                  <p><?php echo $info['date'];?></p>
                                  <br>
                                  <div class="col-6 col-md-3"><p>Officer's Assigned To Gate Duty:</p>
                                    <?php echo $info['gate'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Kitchen Duty:</p>
                                  <?php echo $info['kitchen'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Prison Partrol Duty:</p>
                                  <?php echo $info['partrols'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Night Shift:</p>
                                  <?php echo $info['night'];?></div>
                              </div>
                            </div>
                          </div>
                            <?php } endif; ?>

                            <?php
                          if ($conn){
                            $data =  get('shift_saturday', $conn);
                          }
                          ?> 
                          <?php if ($data) : 
                             foreach ($data as $info) {?>
                        <div class="tab-pane fade" id="nav-saturday" role="tabpanel" aria-labelledby="saturday-tab">
                          <div class="container">
                                <div class="row">
                                  <p><?php echo $info['date'];?></p>
                                  <br>
                                  <div class="col-6 col-md-3"><p>Officer's Assigned To Gate Duty:</p>
                                    <?php echo $info['gate'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Kitchen Duty:</p>
                                  <?php echo $info['kitchen'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Prison Partrol Duty:</p>
                                  <?php echo $info['partrols'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Night Shift:</p>
                                  <?php echo $info['night'];?></div>
                              </div>
                            </div>
                          </div>
                            <?php } endif; ?>

                            <?php
                          if ($conn){
                            $data =  get('shift_sunday', $conn);
                          }
                          ?> 
                          <?php if ($data) : 
                             foreach ($data as $info) {?>
                          <div class="tab-pane fade" id="nav-sunday" role="tabpanel" aria-labelledby="sunday-tab">
                            <div class="container">
                                <div class="row">
                                  <p><?php echo $info['date'];?></p>
                                  <br>
                                  <div class="col-6 col-md-3"><p>Officer's Assigned To Gate Duty:</p>
                                    <?php echo $info['gate'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Kitchen Duty:</p>
                                  <?php echo $info['kitchen'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Prison Partrol Duty:</p>
                                  <?php echo $info['partrols'];?></div>

                                  <div class="col-6 col-md-3"><p>Officer's Assigned Night Shift:</p>
                                  <?php echo $info['night'];?></div>
                              </div>
                            </div>
                          </div>
                            <?php } endif; ?>
                        </div>