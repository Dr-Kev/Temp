<?php
include 'headr.php';

$pos = isset($_POST['upload']);

if(isset($_POST['upload'])){
  $first = $_POST['Fname'];
  $second= $_POST['Sname'];
  $bDay= $_POST['b_date'];
  $aDay= $_POST['add_date'];
  $cel= $_POST['cell'];
  $off= $_POST['offnc'];
  $blok= $_POST['bloc'];
  $gend= $_POST['genderRadios'];
  $idd= $_POST['idNum'];
  $sent= $_POST['cent'];

  $imge = file_get_contents($_FILES['imag']['tmp_name']);
  $img_nme = $_FILES['imag']['name'];
  $target = 'img_upload/' . $img_nme;

  move_uploaded_file($_FILES['imag']['tmp_name'], $target);

  registry("INSERT INTO inmates (img_name,image,fname,sname,cell_No,block,sentence,offence,birth_date,admission_day,gender,id_number) 
            values (:img_name,:image,:fname,:sname,:cell,:blck,:snt,:offence,:birth,:admission,:gender,:id)",
              array('img_name' => $img_nme,
                    'image' => $imge,
                    'fname' => $first,
                    'sname' => $second,
                    'cell' => $cel,
                    'blck' => $blok,
                    'snt' => $sent,
                    'offence' => $off,
                    'birth' => $bDay,
                    'admission' => $aDay,
                    'gender' => $gend,
                    'id' => $idd ), $conn);

  $msg = "Form Posted Succefully";
  $css_class = "alert-success";
} else {
  $msg = "Form Posting Unsuccefull";
  $css_class = "alert-danger";
}
?> 

<script src='lib/bootstrap-select.min.js'></script>
    <div id="wrapper">

        <div class="sectn">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="tagline-message">
                                <img src="inc/images/banner.jpg" style="max-width: 100%">
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end section -->

        <section class="section">
            <div class="container">
                <div class="row">
                            <div class="margin-block"></div>

                    <div class="col-lg-12 col-md-12">

                      <?php if ($pos): ?>
                        <div class="alert <?php echo $css_class; ?>">
                          <?php echo $msg;?>
                        </div>
                      <?php endif; ?>

                        <div class="text-widget">
                            <h3 style="text-align: center; font-style: italic; font-family: 'Courier New', Courier, monospace;">Registration Form</h3>

                 <form class="form-horizontal" action="register.php" method="POST" enctype="multipart/form-data">
                            <div class="col-md-3 text-center">
                                  <label for="imag">Inmate Photo</label>
                            <img src="inc/images/avatar.png" style="max-width: 100%; border-radius: 50%; display: block;" onclick="triggerClick()" id="imagDisplay">
                            <input type="file" id="imag" name="imag" style="display: none;" onchange="displayImage(this)">
                            </div><!-- end col -->

                            <div class="col-md-9"> 
                                            <div class="container">
                                         <div class="form-group">
                                         <label class="control-label col-xs-3" for="firstName">First Name:</label>
                                            <div class="col-xs-9">
                                         <input type="text" class="form-control" name="Fname" id="firstName" placeholder="First Name">
                                             </div>
                                         </div>

                                         <div class="form-group">
                                             <label class="control-label col-xs-3" for="lastName">Last Name:</label>
                                             <div class="col-xs-9">
                                            <input type="text" class="form-control" name="Sname" id="lastName" placeholder="Last Name">
                                            </div>
                                        </div>
                                          
                            <div class="form-group">
                              <label class="control-label col-xs-3" for="offence"></label>
                                <div class="col-xs-4  dates">
                                <input type="text" class="form-control" id="usr1" name="b_date" placeholder="Birth Date" autocomplete="off" >
                                </div>

                                <div class="col-xs-4  dates">
                                <input type="text" class="form-control" id="usr1" name="add_date" placeholder="Admission Date" autocomplete="off" >
                                </div>
                            </div>

                              <div class="form-group">
                                   <label class="control-label col-xs-3" for="idNumber">ID Number:</label>
                                   <div class="col-xs-9">
                                    <input type="text" class="form-control" name="idNum" id="idNumber" placeholder="ID Number">
                                   </div>
                              </div>

                            <div class="form-group">
                                <label class="control-label col-xs-3" for="sentc">Sentence:</label>
                                <div class="col-xs-3">
                                    <input type="text" class="form-control" name="cent" id="sentc" placeholder="Time i.e 2yrs">
                                </div>

                                   <label class="control-label col-xs-3" for="phoneNumber">Cell No:</label>
                                   <div class="col-xs-3">
                                    <input type="text" class="form-control" name="cell" id="cellNumber" placeholder="Assign Cell">
                                   </div>
                              </div>

                            <div class="form-group">
                                <label class="control-label col-xs-3" for="offence">Offence Committed:</label>
                                <div class="col-xs-3">
                                    <select class="form-control" id="offence" name="offnc">
                                        <option>Choose :</option>
                                        <option value="Thief">Thief</option>
                                        <option value="Murderer">Murderer</option>
                                        <option value="Rapist">Rapist</option>
                                    </select>
                                </div>

                                <label class="control-label col-xs-3" for="blocks">Resident Block:</label>
                                <div class="col-xs-3">
                                    <select class="form-control" id="blocks" name="bloc">
                                        <option>Assign :</option>
                                        <option value="A">Block A</option>
                                        <option value="B">Block B</option>
                                        <option value="C">Block C</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="control-label col-xs-3">Gender:</label>
                                <div class="col-xs-2">
                                    <label class="radio-inline">
                                        <input type="radio" name="genderRadios" value="male"> Male
                                    </label>
                                </div>

                                <div class="col-xs-2">
                                    <label class="radio-inline">
                                        <input type="radio" name="genderRadios" value="female"> Female
                                    </label>
                                </div>
                            </div>
                                     <br>
                                     <div class="form-group">
                                          <div class="col-xs-offset-3 col-xs-9">
                                          <input type="submit" name="upload" class="btn btn-primary" value="Submit">
                                          <input type="reset" class="btn btn-success" value="Reset">
                                          </div>
                                     </div>
                                </form>
                               </div>
                            </div>

                            <div class="clearfix"></div>     
                        </div><!-- end widget -->
                    </div><!-- end col-lg-6 -->
                </div><!-- end row -->
            </div><!-- end container -->
            </div>
        </section>
                    <div class="margin-block"></div>

<?php 
include'footr.php';
?> 
