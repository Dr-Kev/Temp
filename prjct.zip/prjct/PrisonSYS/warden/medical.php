<?php 
include'headr.php';

if (isset($_POST['upload'])){

  $do = $_POST['doc'];
  $fn = $_POST['Fname'];
  $sn = $_POST['Sname'];
  $da = $_POST['add_date'];
  $di = $_POST['dis'];
  $re = $_POST['rec'];

   registry("INSERT INTO medical_records (doctor,fname,sname,admission_date,diagnosis,recommendations) 
             values (:doc,:first,:second,:day,:diag,:reco)",
               array('doc' => $do,
                     'first' => $fn,
                     'second' => $sn, 
                     'day' => $da,
                     'diag' => $di,
                     'reco' => $re) ,$conn);
} 
?> 

    <div id="wrapper">
        <div class="sectin">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="tagline-message">
                            <img src="inc/images/banner.jpg" style="max-width: 100%">
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end section -->

        <section class="section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="text-widget">
                            <h3 style="text-align: left; margin-top: -80px; font-size: 18px; font-family:'Courier New', Courier, monospace;">
                            Medical Records:
                            </h3>
                            <div>
                              <a href="#" data-toggle="modal" data-target="#modalmedic">
                              <input type="button" value="Record Treatment" style="background-color: #4CAF50; color: white; cursor: pointer; border-radius: 20px;">
                              </a>
                            </div>

                            <div class="margin-block"></div>

                        <div class="table-responsive">
                                    <table class="table table-hover">
                                    <thead style="background-color: darkgrey;">
                                      <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Attendingn Doctor</th>
                                        <th scope="col">Names</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Diagnosis</th>
                                        <th scope="col">Recommendations</th>
                                        <th scope="col">More</th>
                                      </tr>
                                    </thead>

                          <?php
                          if ($conn){
                            $data =  get('medical_records', $conn);
                          } else die('Could Not Connect');
                          ?> 
                          <?php if ($data) : 
                             $i=1;
                             // $count = $data->rowCount(); 
                             foreach ($data as $info) {?>
                                    <tbody>
                                      <tr>
                                      <th scope="row"> <?php echo $i;  $i++;?></th>
                                      <td style="display: none;"> <?php echo $info['id'];?></td>
                                      <td> <?php echo $info['doctor'];?></td>
                                      <td> <?php echo $info['fname']." ".$info['sname'];?></td>
                                      <td> <?php echo $info['admission_date'];?></td>
                                      <td> <?php echo $info['diagnosis'];?></td>
                                      <td> <?php echo $info['recommendations'];?></td>
                                      <td>
                                        <a href="#"  data-toggle="modal">
                                        <input type="button" value="Review" class="medbtn" style="background-color: #4CAF50; color: white; cursor: pointer; border-radius: 20px;">
                                        </a>
                                      </td>
                                      </td>
                                    </tr>
                                    </tbody> 

                            <?php } endif; ?>

                                  </table>
                                </div>
                        </div><!-- end widget -->
                    </div><!-- end col-lg-6 -->
                </div><!-- end row -->
            </div><!-- end container -->
        </section>
                    <div class="margin-block"></div>

   <!-- Medical Modal -->
<div id="modalmedic" class="modal fade" role="dialog" style="max-width: 100%;">
  <div class="modal-dialog" style="margin-top: 50px;">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="text-align: center; font-style: italic; font-family: 'Courier New', Courier, monospace;">Medical Rcord</h4>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" action="medical.php" method="POST" enctype="multipart/form-data">
          <div class="container">
            <div class="form-group">
                      <label class="control-label col-xs-3" for="doc">Doctor's Name:</label>
                        <div class="col-xs-9">
                        <input type="text" class="form-control" name="doc" id="doc" placeholder="Doctor's Name">
                        </div>
                     </div>

                     <div class="form-group">
                      <label class="control-label col-xs-3" for="firstName">First Name:</label>
                        <div class="col-xs-9">
                        <input type="text" class="form-control" name="Fname" id="firstName" placeholder="Inmate First Name">
                        </div>
                     </div>

            <div class="form-group">
               <label class="control-label col-xs-3" for="lastName">Last Name:</label>
                <div class="col-xs-9">
                <input type="text" class="form-control" name="Sname" id="lastName" placeholder="Inmates Last Name">
                  </div>
             </div>
            <div class="form-group">
                <label class="control-label col-xs-3" for="usr1">Date:</label>
                                <div class="col-xs-4  dates">
                                <input type="text" class="form-control" id="usr1" name="add_date" placeholder="Admission Date" autocomplete="off" >
                                </div>
                            </div>

              <div class="form-group">
                <label class="control-label col-xs-3" for="dis">Diagnosis:</label>
                <div class="col-xs-9">
                      <textarea rows="3" class="form-control" name="dis" id="dis" placeholder="Brief Description" ></textarea>
                </div>
              </div>                                         
              <div class="form-group">
               <label class="control-label col-xs-3" for="rec">Recommendations:</label>
                    <div class="col-xs-9">
                      <textarea rows="3" class="form-control" name="rec" id="rec" value="" ></textarea>
                    </div>
              </div>
                 <br>
                   <div class="form-group">
                                <div class="col-xs-offset-5 col-xs-9">
                                <input type="submit" name="upload" class="btn btn-primary" value="Submit">
                                </div>
                  </div>
          </div>
        </form>
      </div>
    </div>

  </div>
</div>
  

  <!-- view Modal -->  
<div id="med_modal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="text-align: center; font-style: italic; font-family: 'Courier New', Courier, monospace;">Review Medical Record</h4>
      </div>
    <div class="loginbox">
      <div class="modal-body">
        <form class="form-horizontal" action="medical.php" method="POST" enctype="multipart/form-data">
          <div class="container">

            <input type="hidden" name="update_id" id="update_id">

            <div class="form-group">
                      <label class="control-label col-xs-3" for="doc">Doctor's Name:</label>
                        <div class="col-xs-9">
                        <input type="text" class="form-control" name="Mdoc" id="Mdoc" placeholder="Doctor's Name">
                        </div>
           </div>

            <div class="form-group">
                      <label class="control-label col-xs-3" for="MName">Inmate Name:</label>
                        <div class="col-xs-9">
                        <input type="text" class="form-control" name="Mname" id="MName" placeholder="Inmate Name">
                        </div>
            </div>

            <div class="form-group">
                <label class="control-label col-xs-3" for="day">Date:</label>
                 <div class="col-xs-9">
                 <input type="text" class="form-control" id="day" name="day" placeholder="Admission Date">
                </div>
           </div>

              <div class="form-group">
                <label class="control-label col-xs-3" for="Mdis">Diagnosis:</label>
                <div class="col-xs-9">
                      <textarea rows="3" class="form-control" name="Mdis" id="Mdis" placeholder="Brief Description" ></textarea>
                </div>
              </div>                                         
              <div class="form-group">
               <label class="control-label col-xs-3" for="Mrec">Recommendations:</label>
                    <div class="col-xs-9">
                      <textarea rows="3" class="form-control" name="Mrec" id="Mrec" value="" ></textarea>
                    </div>
              </div>
                 <br>
                   <div class="form-group">
                      <div class="col-xs-offset-3 col-xs-9">
                        <input type="button" name="uploadMed" class="btn btn-danger close" value="Close" data-dismiss="modal">
                       </div>
                  </div>
          </div>
        </form>
      </div>
        </div>
    </div>
  </div>
</div>   

<?php 
include'footr.php';
?> 
