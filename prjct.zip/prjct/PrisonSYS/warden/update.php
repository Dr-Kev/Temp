 <?php

include '../functions/config.php';
include '../functions/db.php';

if(isset($_POST['update_work'])) {
  $id = $_POST['update_id'];

  $ti = $_POST['Wtitle'];
  $des = $_POST['Wdesc'];
  $inm = $_POST['Winm'];
  $per = $_POST['Wperf'];

  registry("UPDATE work SET title=:tit, description=:dec, inmate_assigned =:inmate, review=:rev WHERE work_id =:id",
              array('id' => $id,
                    'tit' => $ti,
                    'dec' => $des,
                    'inmate' => $inm,
                    'rev' => $per) ,$conn);
  header('Location:work.php');
}

if(isset($_POST['update_user'])) {
  $id = $_POST['update_id'];

  $ti = $_POST['Wtitle'];
  $des = $_POST['Wdesc'];
  $inm = $_POST['Winm'];

  registry("UPDATE logins SET username=:tit, password=:dec, category=:inmate WHERE id=:id",
              array('id' => $id,
                    'tit' => $ti,
                    'dec' => $des,
                    'inmate' => $inm) ,$conn);
  header('Location:login_creds.php');
}
  ?>
     