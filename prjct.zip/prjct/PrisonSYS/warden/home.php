
<?php 
include'headr.php';
?> 

    <div id="wrapper">

        <div class="sectin">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="tagline-message">
                            <img src="inc/images/banner.jpg" style="max-width: 100%">
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end section -->

        <section class="section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="text-widget">
                            <h3 style="text-align: left; margin-top: -80px; font-size: 18px; font-family:'Courier New', Courier, monospace;">
                            Welcome: <?php echo $_SESSION['user2'];?>
                            </h3>
                            <p>Prison Name: INDUSTRIAL AREA REMAND PRISON</p> 

                            <div class="row">
                                <div class="col-lg-1 col-md-1 col-sm-1">
                                </div><!-- end col-lg-4 --> 
                                <div class="col-lg-3 col-md-3 col-sm-3">
                                    <?php
                                    $stmt = $conn->prepare('SELECT * FROM inmates');
                                    $stmt->execute();
                                    $count1 = $stmt->rowCount();
                                    ?>
                                    <ul class="check">
                                        <li>Number of Inmates : &nbsp;<?php echo $count1;?></li>
                                    </ul><!-- end check -->
                                </div><!-- end col-lg-4 -->

                                <?php
                                    $stmt = $conn->prepare('SELECT * FROM staff');
                                    $stmt->execute();
                                    $count2 = $stmt->rowCount();
                                ?>
                                <div class="col-lg-3 col-md-3 col-sm-4">
                                    <ul class="check">
                                        <li>Number of Staff Members: &nbsp;<?php echo $count2;?></li>
                                    </ul><!-- end check -->    
                                </div><!-- end col-lg-4 -->
                                <div class="col-lg-3 col-md-3 col-sm-3">
                                </div><!-- end col-lg-4 --> 
                            </div><!-- end row -->
                            
                        </div><!-- end widget -->
                    </div><!-- end col-lg-6 -->
                </div><!-- end row -->
            </div><!-- end container -->
        </section>

        <section class="shift">
            <div class="container">
                <div class="row">
                    <div class="col-lg-2">
                        <ul>
                    <li style="list-style: none;">Guard Shifts &nbsp;&nbsp;<span class="fa fa-angle-right"></span></li>    
                        </ul>
                    </div>
                    <div class="col-lg-9">
                          <ul class="nav nav-tabs" id="myTab" role="tablist">
                          <li class="nav-item">
                           <a class="nav-link" id="monday-tab" data-toggle="tab" href="#nav-monday" role="tab" aria-controls="nav-monday" aria-selected="true">Monday</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="tuesday-tab" data-toggle="tab" href="#nav-tuesday" role="tab" aria-controls="nav-tuesday" aria-selected="false">Tuesday</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="wednesday-tab" data-toggle="tab" href="#nav-wednesday" role="tab" aria-controls="nav-wednesday" aria-selected="false">Wednesday</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="thursday-tab" data-toggle="tab" href="#nav-thursday" role="tab" aria-controls="nav-thursday" aria-selected="false">Thursday</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="friday-tab" data-toggle="tab" href="#nav-friday" role="tab" aria-controls="nav-friday" aria-selected="false">Friday</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="saturday-tab" data-toggle="tab" href="#nav-saturday" role="tab" aria-controls="nav-saturday" aria-selected="false">Saturday</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="sunday-tab" data-toggle="tab" href="#nav-sunday" role="tab" aria-controls="nav-sunday" aria-selected="false">Sunday</a>
                          </li>
                        </ul>

                    <?php include'shift_view.php'; ?>

                    </div>
                    <div class="col-lg-1"></div>
                </div>
            </div>
        </section>
                    <div class="margin-block"></div>
                    <div class="margin-block"></div>

        <section class="section lb nopadtop noover" style="margin-top: -3%;">
        <li style="list-style: none; margin-left: 2.5%;">Prison Events &nbsp;&nbsp;<span class="fa fa-angle-down"></span></li>
                            <div class="margin-block"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-12">
                        <div class="service-box m30">
                            <i class="flaticon-monitor"></i>
                            <h3>Sports</h3>
                            <p>The Prisons Inter-regional Athletics/Darts /Volleyball Championship ongoing at Moi International Sports Center Kasarani.Events as they unfolded today.</p>
                        </div>
                    </div><!-- end col -->

                    <div class="col-lg-3 col-md-12">
                        <div class="service-box m30">
                            <i class="flaticon-monitor"></i>
                            <h3>New Computers Donated</h3>
                            <p>As of January 2020, the government is donate 100 desktop computers to Industrial area prison.</p>
                        </div>
                    </div><!-- end col -->

                    <div class="col-lg-3 col-md-12">
                        <div class="service-box m30">
                            <i class="flaticon-technology"></i>
                            <h3>Inmates Graduates</h3>
                            <p>Inmates from different faculities to gradute soon.</p>
                        </div>
                    </div><!-- end col -->

                    <div class="col-lg-3 col-md-12">
                        <div class="service-box m30">
                            <i class="flaticon-gears"></i>
                            <h3>Prison Inmates Premier League</h3>
                            <p>Kenyan Premier League and Zeb Strong Foundation wish to thank members of The Press who came to the Kamiti Maximum Prison on Thursday 13th June 2019 to provide coverage for our event at the correctional facility.</p>
                            <!-- https://www.kenyanpremierleague.com/2019/06/13/press-release-conclusion-of-the-kamiti-maximum-prison-inmates-premier-league/ -->
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </section><!-- end section -->

<?php 
include'footr.php';
?> 
