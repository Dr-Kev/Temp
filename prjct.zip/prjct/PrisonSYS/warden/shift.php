
<?php 
include'headr.php';

if (isset($_POST['upload'])){

  $when = $_POST['cat'];
  $gate = $_POST['gate'];
  $kitchen = $_POST['kitchen'];
  $partrol = $_POST['partrol'];
  $night = $_POST['night'];
  $day = date("Y-m-d");

 include'shift_db.php';
}
?>
    <div id="wrapper">
        <div class="sectin">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="tagline-message">
                            <img src="inc/images/banner.jpg" style="max-width: 100%">
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end section -->

        <section class="section">
            <div class="container">
                <div class="row">
                   <div class="col-lg-2">
                      <h3 style="text-align: left; margin-top: -80px; font-size: 18px; font-family:'Courier New', Courier, monospace;">
                            Assign Shift:
                      </h3>
                            <div class="top">
                              <a href="#" data-toggle="modal" data-target="#shiftmodal">
                              <input type="button" value="New Shift" style="background-color: #4CAF50; color: white; cursor: pointer; border-radius: 20px;">
                              </a>
                            </div>

                        <ul><li style="list-style: none;">Guard Shifts &nbsp;&nbsp;<span class="fa fa-angle-right"></span></li>    
                        </ul>
                    </div>

                    <div class="col-lg-9">
                          <ul class="nav nav-tabs" id="myTab" role="tablist">
                          <li class="nav-item active">
                           <a class="nav-link" id="monday-tab" data-toggle="tab" href="#nav-monday" role="tab" aria-controls="nav-monday" aria-selected="true">Monday</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="tuesday-tab" data-toggle="tab" href="#nav-tuesday" role="tab" aria-controls="nav-tuesday" aria-selected="false">Tuesday</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="wednesday-tab" data-toggle="tab" href="#nav-wednesday" role="tab" aria-controls="nav-wednesday" aria-selected="false">Wednesday</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="thursday-tab" data-toggle="tab" href="#nav-thursday" role="tab" aria-controls="nav-thursday" aria-selected="false">Thursday</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="friday-tab" data-toggle="tab" href="#nav-friday" role="tab" aria-controls="nav-friday" aria-selected="false">Friday</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="saturday-tab" data-toggle="tab" href="#nav-saturday" role="tab" aria-controls="nav-saturday" aria-selected="false">Saturday</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="sunday-tab" data-toggle="tab" href="#nav-sunday" role="tab" aria-controls="nav-sunday" aria-selected="false">Sunday</a>
                          </li>
                        </ul>
                        
                    <?php include'shift_view.php'; ?>

                    </div>
                    <div class="col-lg-1"></div>
                </div>
            </div>
        </section>
                    <div class="margin-block"></div>


  

   <!--Shift Modal -->
<div class="modal fade" id="shiftmodal" tabindex="-1" role="dialog" aria-hidden="true" style="max-width: 100%;">
  <div class="modal-dialog" style="margin-top: 50px;">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="text-align: center; font-style: italic; font-family: 'Courier New', Courier, monospace;">Assign Duties</h4>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" method="POST" action="shift.php" enctype="multipart/form-data">
          <div class="container"> 
          
          <input type="hidden" name="update_id" id="update_id">

            <div class="form-group">
               <label class="control-label col-xs-3" for="cat">Pick Day:</label>
               <div class="col-xs-9">
                <select class="form-control" id="cat" name="cat">
                  <option disabled selected>Choose the day:</option>
                  <option value="Monday">Monday</option>
                  <option value="Tuesday">Tuesday</option>
                  <option value="Wednesday">Wednesday</option>
                  <option value="Thursday">Thursday</option>
                  <option value="Friday">Friday</option>
                  <option value="Saturday">Saturday</option>
                  <option value="Sunday">Sunday</option>
                </select>
               </div>
              </div>
          
            <div class="form-group">
               <label class="control-label col-xs-3" for="gate">Gate Duty:</label>
               <div class="col-xs-9">
                <input type="text" class="form-control" name="gate" id="gate">
               </div>
              </div>

              <div class="form-group">
                <label class="control-label col-xs-3" for="kitchen">Kitchen Duty:</label>
                <div class="col-xs-9">
                  <input type="text" class="form-control" name="kitchen" id="kitchen">
              </div>
            </div>

              <div class="form-group">
               <label class="control-label col-xs-3" for="partrol">Partrols:</label>
               <div class="col-xs-9">
              <textarea rows="4" cols="45" name="partrol" id="partrol" placeholder="partrol Guards..."></textarea>
               </div>
              </div>

              <div class="form-group">
                <label class="control-label col-xs-3" for="night">Night Shift:</label>
                <div class="col-xs-9">
              <textarea rows="4" cols="45" name="night" id="night" placeholder="Night Shift Guards..."></textarea>
                </div>
              </div>
                 <br>

                <div class="form-group">
                 <div class="col-xs-offset-3 col-xs-9">
                   <input type="submit" name="upload" class="btn btn-primary" value="Submit" style="cursor: pointer; border-radius: 20px;">
                   <input type="reset" class="btn btn-success" value="Reset" style="cursor: pointer; border-radius: 20px;">
                 </div>
              </div>

          </div>
        </form>
      </div>
    </div>

  </div>
</div>  

<?php 
include'footr.php';
?> 
