
<?php 
include'headr.php';
if (isset($_POST['upload'])){

  $tit = $_POST['title'];
  $des = $_POST['desc'];
  $inmat = $_POST['inm'];
  $newValues = implode(",", $inmat);

   registry("INSERT INTO work (title,description,inmate_assigned) 
             values (:tite,:descrip,:ass)",
               array('tite' => $tit,
                     'descrip' => $des,
                     'ass' => $newValues) ,$conn);
}
?>
<script src='lib/bootstrap-select.min.js'></script>
    <div id="wrapper">
        <div class="sectin">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="tagline-message">
                            <img src="inc/images/banner.jpg" style="max-width: 100%">
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end section -->

        <section class="section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="text-widget">
                            <h3 style="text-align: left; margin-top: -80px; font-size: 18px; font-family:'Courier New', Courier, monospace;">
                            Work Records:
                            </h3>
                            <div>
                              <a href="#" data-toggle="modal" data-target="#modalwork">
                              <input type="button" value="New Job" style="background-color: #4CAF50; color: white; cursor: pointer; border-radius: 20px;">
                              </a>
                            </div>

                            <div class="margin-block"></div>

                        <div class="table-responsive">
                                    <table class="table table-hover">
                                    <thead style="background-color: darkgrey;">
                                      <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Work Title</th>
                                        <th scope="col">Description</th>
                                        <th scope="col">Inmate's Assigned</th>
                                        <th scope="col">Perfomance Review</th>
                                        <th scope="col">More Details</th>
                                      </tr>
                                    </thead>
                          <?php
                          if ($conn){
                            $data =  get('work', $conn);
                          } else die('Could Not Connect');
                          ?> 

                          <?php 

                             $i=1;
                             if ($data) : 
                             // $count = $data->rowCount(); 
                             foreach ($data as $info) {?>
                                    <tbody>
                                      <tr>
                                      <th scope="row"> <?php echo $i; $i++;?></th>
                                      <td style="display: none;"> <?php echo $info['work_id'];?></td>
                                      <td> <?php echo $info['title'];?></td>
                                      <td> <?php echo $info['description'];?></td>
                                      <td> <?php echo $info['inmate_assigned']; ?></td>
                                      <td> <?php echo $info['review']; ?></td>
                                      <td>
                                      <a href="#"  data-toggle="modal">
                                        <input type="button" value="Review" class="workbtn" style="background-color: #4CAF50; color: white; cursor: pointer; border-radius: 20px;">
                                        </a>
                                      </td>
                                    </tr>
                                        
                                    </tbody>

                            <?php } endif; ?>

                                  </table>
                                </div>
                        </div><!-- end widget -->
                    </div><!-- end col-lg-6 -->
                </div><!-- end row -->
            </div><!-- end container -->
        </section>
                    <div class="margin-block"></div>




      <!-- Work Modal -->
<div id="modalwork" class="modal fade" role="dialog" style="max-width: 100%;">
  <div class="modal-dialog" style="margin-top: 50px;">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="text-align: center; font-style: italic; font-family: 'Courier New', Courier, monospace;">Work Details</h4>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" action="work.php" method="POST" enctype="multipart/form-data">
          <div class="container">                                          
              <div class="form-group">
               <label class="control-label col-xs-4" for="title">Title:</label>
                    <div class="col-xs-8">
                      <input type="text" class="form-control" name="title" id="title" placeholder="Title of Work">
                    </div>
              </div>

              <div class="form-group">
                <label class="control-label col-xs-4" for="desc">Description:</label>
                <div class="col-xs-8">
                      <textarea rows="3" class="form-control" name="desc" id="desc" placeholder="Brief Description" ></textarea>
                </div>
              </div>                                         
              <div class="form-group">
               <label class="control-label col-xs-4" for="inm">Inmate's Assigned:</label>
               <?php 
               if ($conn){
                $data2 = get('inmates',$conn);
               }
                ?>
                    <div class="col-xs-8">
                      <select class="selectpicker" multiple data-live-search="true" name="inm[]">
                    <?php foreach ($data2 as $row){                ?>
                      <option value="<?php echo $row['fname']." ".$row['sname'];?>">
                        <?php echo $row['fname']." ".$row['sname'];?>
                      </option>
                     <?php }?>
                    </select>
                    </div>
              </div>

                 <br>
                   <div class="form-group">
                                <div class="col-xs-offset-5 col-xs-9">
                                <input type="submit" name="upload" class="btn btn-primary" value="Submit">
                                </div>
                  </div>

          </div>
        </form>
      </div>
    </div>

  </div>
</div>
  

   <!-- Review Modal -->
<div class="modal fade" id="editmodal" tabindex="-1" role="dialog" aria-hidden="true" style="max-width: 100%;">
  <div class="modal-dialog" style="margin-top: 50px;">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="text-align: center; font-style: italic; font-family: 'Courier New', Courier, monospace;">Work Review Details</h4>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" method="POST" action="update.php" enctype="multipart/form-data">
          <div class="container"> 
          
          <input type="hidden" name="update_id" id="update_id">
          
            <div class="form-group">
               <label class="control-label col-xs-3" for="Wtitle">Work Title:</label>
               <div class="col-xs-9">
                <input type="text" class="form-control" name="Wtitle" id="Wtitle">
               </div>
              </div>
              <div class="form-group">
                <label class="control-label col-xs-3" for="Wdesc">Description:</label>
                <div class="col-xs-9">
                  <input type="text" class="form-control" name="Wdesc" id="Wdesc">
              </div>
            </div>

              <div class="form-group">
               <label class="control-label col-xs-3" for="Winm">Inmate's Assigned:</label>
               <div class="col-xs-9">
                  <input type="text" class="form-control" name="Winm" id="Winm">
               </div>
              </div>

              <div class="form-group">
                <label class="control-label col-xs-3" for="Wperf">Performance Review:</label>
                <div class="col-xs-9">
                  <input type="text" class="form-control" name="Wperf" id="Wperf">
                </div>
              </div>
                 <br>
                   <div class="form-group">
                                <div class="col-xs-offset-5 col-xs-9">
                                <input type="submit" name="update_work" class="btn btn-primary" value="Submit">
                                </div>
                  </div>

<!-- <?php // }  ?> -->
          </div>
        </form>
      </div>
    </div>

  </div>
</div>  

<?php 
include'footr.php';
?> 
