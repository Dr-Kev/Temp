<?php 
include'headr.php';

if(isset($_POST['upload'])){
 
  $name= $_POST['Oname'];
  $tim = date("Y-m-d h:i:s a");

  $fil = file_get_contents($_FILES['fil']['tmp_name']);
  $file_nme = $_FILES['fil']['name'];
  $target = 'monthyRep/' . $file_nme;

  move_uploaded_file($_FILES['fil']['tmp_name'], $target);

  registry("INSERT INTO daily (Officer,file_name,file,date) 
            values (:off,:nm,:file,:day)",
              array('off' => $name,
                    'nm'  => $file_nme,
                    'file'=> $fil,
                    'day' => $tim), $conn);
} 
?> 

    <div id="wrapper">
        <div class="sectin">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="tagline-message">
                            <img src="inc/images/banner.jpg" style="max-width: 100%">
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end section -->

        <section class="section"> 
          <div class="col-lg-12 col-md-12">
            <div class="container">
                <div class="row">
                        <div class="text-widget">
                            <h3 style="text-align: left; margin-top: -80px; font-size: 18px; font-family:'Courier New', Courier, monospace;">
                            Monthly Reports:
                            </h3>
                            <div>
                              <div class="col-lg-4">
                              <a href='monthlyRep/forms/Monthly_report_form.docx'>
                              <input type="button" value="Download Form" style="background-color: #4CAF50; color: white; cursor: pointer; border-radius: 20px;">
                              </a>
                              </div>

                              <div class="col-lg-4"></div>

                             <div class="col-lg-4">
                              <a href="#" data-toggle="modal" data-target="#modaldaily">
                              <input type="button" value="Upload Report" style="background-color: #4CAF50; color: white; cursor: pointer; border-radius: 20px;">
                              </a>
                            </div>
                            </div>

                            <div class="margin-block"></div>

                        <div class="table-responsive">
                                    <table class="table table-hover">
                                    <thead style="background-color: darkgrey;">
                                      <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Officer's  Name</th>
                                        <th scope="col">Report</th>
                                        <th scope="col">Details</th>
                                      </tr>
                                    </thead>

                          <?php
                          if ($conn){
                            $data =  get('daily', $conn);
                          } else die('Could Not Connect');
                          ?> 
                          <?php if ($data) : 
                             $i=1;
                             // $count = $data->rowCount(); 
                             foreach ($data as $info) {?>
                                    <tbody>
                                      <tr>
                                      <th scope="row"> <?php echo $i;  $i++;?></th>
                                      <td style="display: none;"> <?php echo $info['id'];?></td>
                                      <td> <?php echo $info['date'];?></td>
                                      <td> <?php echo $info['Officer'];?></td>
                                      <td> <?php echo $info['file_name'];?></td>
                                      <td>
                                        <?php echo "<a href='dailyRep/{$info['file_name']}'>" ?>
                                        <input type="button" value="Download" class="medbtn" style="background-color: #4CAF50; color: white; cursor: pointer; border-radius: 20px;">
                                        </a>
                                      </td>
                                      </td>
                                    </tr>
                                    </tbody> 

                            <?php } endif; ?>

                                  </table>
                                </div>
                        </div><!-- end widget -->
                    </div><!-- end col-lg-6 -->
                </div><!-- end row -->
            </div><!-- end container -->
        </section>
                    <div class="margin-block"></div>

    <!-- Report Modal -->
<div id="modaldaily" class="modal fade" role="dialog" style="max-width: 100%;">
  <div class="modal-dialog" style="margin-top: 50px;">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="text-align: center; font-style: italic; font-family: 'Courier New', Courier, monospace;">UPLOAD MONTHLY REPORT</h4>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" action="daily.php" method="POST" enctype="multipart/form-data">
          <div class="form-group">
              <label class="control-label col-xs-3" for="Oame">Officer's Name:</label>
              <div class="col-xs-9">
              <input type="text" class="form-control" name="Oname" id="Oname" placeholder="Name">
              </div>
          </div>

          <div class="form-group" style="margin-left: 1%;">
          <input type="file" class="form-control-file" id="fil" name="fil">
          </div>


              <div class="form-group">
                 <div class="col-xs-offset-3 col-xs-9">
                   <input type="submit" name="upload" class="btn btn-primary" value="Submit" style="cursor: pointer; border-radius: 20px;">
                   <input type="reset" class="btn btn-success" value="Reset" style="cursor: pointer; border-radius: 20px;">
                 </div>
              </div>
        </div>
        </form>
      </div>
    </div>

  </div>
</div>
  
<?php 
include'footr.php';
?> 
