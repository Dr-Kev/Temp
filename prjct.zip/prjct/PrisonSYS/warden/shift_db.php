<?php
switch ($when) {
		case 'Monday':
   registry("INSERT INTO shift_monday (gate,kitchen,partrols,night,date) values (:gat,:kit,:part,:nig,:tim)",
             array('gat' => $gate,'kit' => $kitchen,'part'=> $partrol,'nig' => $night,'tim' => $day) 
             ,$conn);
			break;

		case 'Tuesday':
   registry("INSERT INTO shift_tuesday (gate,kitchen,partrols,night,date) values (:gat,:kit,:part,:nig,:tim)",
             array('gat' => $gate,'kit' => $kitchen,'part'=> $partrol,'nig' => $night,'tim' => $day) 
             ,$conn);
			break;

		case 'Wednesday':
   registry("INSERT INTO shift_wednesday (gate,kitchen,partrols,night,date) values (:gat,:kit,:part,:nig,:tim)",
             array('gat' => $gate,'kit' => $kitchen,'part'=> $partrol,'nig' => $night,'tim' => $day) 
             ,$conn);
			break;

		case 'Thursday':
   registry("INSERT INTO shift_thursday (gate,kitchen,partrols,night,date) values (:gat,:kit,:part,:nig,:tim)",
             array('gat' => $gate,'kit' => $kitchen,'part'=> $partrol,'nig' => $night,'tim' => $day) 
             ,$conn);
			break;

		case 'Friday':
   registry("INSERT INTO shift_friday (gate,kitchen,partrols,night,date) values (:gat,:kit,:part,:nig,:tim)",
             array('gat' => $gate,'kit' => $kitchen,'part'=> $partrol,'nig' => $night,'tim' => $day) 
             ,$conn);
			break;

		case 'Saturday':
   registry("INSERT INTO shift_saturday (gate,kitchen,partrols,night,date) values (:gat,:kit,:part,:nig,:tim)",
             array('gat' => $gate,'kit' => $kitchen,'part'=> $partrol,'nig' => $night,'tim' => $day) 
             ,$conn);
			break;

		case 'Sunday':
   registry("INSERT INTO shift_sunday (gate,kitchen,partrols,night,date) values (:gat,:kit,:part,:nig,:tim)",
             array('gat' => $gate,'kit' => $kitchen,'part'=> $partrol,'nig' => $night,'tim' => $day) 
             ,$conn);
			break;

		default:
			echo "ERROR!!";
			break;
	}