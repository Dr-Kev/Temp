
<?php 
include'headr.php';

if (isset($_POST['uploadV'])){

  $inm = $_POST['inmateName'];
  $Vn = $_POST['vName'];
  $idN = $_POST['IDNumber'];
  $phon = $_POST['phoneNumber'];
  $gen = $_POST['genderRadios'];
  $tim = date("Y-m-d h:i:s a");

   registry("INSERT INTO visits (inmate,visitor,id_number,phone,gender,time) 
             values (:inmate,:visit,:id_num,:phone,:gend,:day)",
               array('inmate' => $inm,
                     'visit' => $Vn,
                     'id_num' => $idN, 
                     'phone' => $phon,
                     'gend' => $gen,
                     'day' => $tim) ,$conn);
}
?> 
 
<body class="left-menu">    
    <div class="menu-wrapper">
        <div class="mobile-menu">
            <nav class="navbar navbar-inverse">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="index.html"><img src="inc/images/logo-normal.png" alt=""></a>
                    </div>
                    <div id="navbar" class="navbar-collapse collapse">
                        <ul class="nav navbar-nav">
                            <li class="dropdown">
                                <a href="login.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Home<span class="fa fa-angle-down"></span></a>
                            </li>
                        </ul>
                    </div><!--/.nav-collapse -->
                </div><!--/.container-fluid -->
            </nav>
        </div><!-- end mobile-menu -->

        <header class="vertical-header">
            <div class="vertical-header-wrapper">
                <nav class="nav-menu">
                    <div class="logo">
                        <a href="#"><img src="inc/images/gok.gif" alt="" style="width: 180px; height: 180px; margin-top: -32%"></a>
                    </div><!-- end logo -->

                    <div class="margin-block"></div>

                    <ul class="primary-menu">
                        <li class="child-menu"><a href="login.php">Home<i class="fa fa-angle-right"></i></a>
                        </li>
                    </ul>
                    
                    <div class="margin-block"></div>

                    <div class="margin-block"></div>

                    <div class="menu-social">
                        <ul class="list-inline text-center">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                    </div><!-- end menu -->
                </nav><!-- end nav-menu -->
            </div><!-- end vertical-header-wrapper -->
        </header><!-- end header -->
    </div><!-- end menu-wrapper -->

    <div id="wrapper">

        <div class="sectn">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="tagline-message">
                                <img src="inc/images/banner.jpg" style="max-width: 100%">
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end section -->

        <section class="section">
            <div class="container">
                <div class="row">

                    <div class="col-lg-12 col-md-12">
                        <div class="text-widget">
                            <h3 style="text-align: center; font-style: italic; font-family: 'Courier New', Courier, monospace;">Visitation Form</h3>

                            <div class="col-md-12"> 
                                <div class="container">
                                            </br>
                                         <form class="form-horizontal" method="POST" action="">
                                             <div class="form-group">
                                                 <label class="control-label col-xs-3" for="inmateName">Inmate Name:</label>
                                                 <div class="col-xs-9">
                                                 <input type="text" class="form-control" name="inmateName" id="inmateName" placeholder="Inmate Name">
                                             </div>
                                             </div>

                                             <div class="form-group">
                                                 <label class="control-label col-xs-3" for="vName">Visitor Name:</label>
                                                 <div class="col-xs-9">
                                                 <input type="text" class="form-control" name="vName" id="vName" placeholder="Visitor's Name">
                                             </div>
                                              </div>

                                <div class="form-group">
                                   <label class="control-label col-xs-3" for="phoneNumber">ID Number:</label>
                                   <div class="col-xs-9">
                                        <input type="text" class="form-control" name="IDNumber" id="IDNumber" placeholder="ID Number">
                                    </div>
                                </div>

                                <div class="form-group">
                                       <label class="control-label col-xs-3" for="phoneNumber">Phone:</label>
                                       <div class="col-xs-9">
                                        <input type="tel" class="form-control" name="phoneNumber" id="phoneNumber" placeholder="Phone Number">
                                       </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-xs-3">Gender:</label>
                                    <div class="col-xs-2">
                                        <label class="radio-inline">
                                            <input type="radio" name="genderRadios" value="male"> Male
                                        </label>
                                    </div>

                                    <div class="col-xs-2">
                                        <label class="radio-inline">
                                            <input type="radio" name="genderRadios" value="female"> Female
                                        </label>
                                    </div>
                                </div>
                                         
                                    <div class="form-group">
                                          <div class="col-xs-offset-3 col-xs-9">
                                          <input type="submit" name="uploadV" class="btn btn-primary" value="Submit" style="background-color: #4CAF50; color: white; cursor: pointer; border-radius: 20px;">
                                          <input type="reset" class="btn btn-success" value="Reset" style="background-color: #4CAF50; color: white; cursor: pointer; border-radius: 20px;">
                                          </div>
                                    </div>
                                         </form>
                                   </div>   
                            </div>

                            <div class="clearfix"></div>     
                        </div><!-- end widget -->
                    </div><!-- end col-lg-6 -->
                </div><!-- end row -->
            </div><!-- end container -->
            <div class="perspective-image hidden-sm hidden-xs hidden-md"> 
                <img src="images/upload/p1.jpg" alt="" class="img-responsive">
            </div>
        </section>
                    <div class="margin-block"></div>


        <div class="section copyrights">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-3">
                            <img src="inc/images/gok.gif" alt="" style="height: 50px; width: 50px;">
                    </div>
                    <div class="col-lg-9 col-md-9 text-right">
                        <div class="cop-links">
                            <ul class="list-inline">
                                <li>&copy; 2019 Kenya Prison's Info System | Designer: <a href="#">Dr~K</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- end wrapper -->

<?php 
include'footr.php';
?> 