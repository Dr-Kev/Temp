<?php
 function is_logged_in($user){
 	return isset($user);
 }

 function validate_type ($category) {
 	return ($category == 'guard' || $category == 'warden');
 }
 
 function validate_user_creds ($user, $pass, $type, $data){
 	return ($user == $data['username'] && $pass == $data['password'] && $type == $data['category']);
 }

