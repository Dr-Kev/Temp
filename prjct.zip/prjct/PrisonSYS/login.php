
<?php 
include'headr.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    $category = $_POST['cat'];
    $username = $_POST['inputUname'];
    $password = $_POST['inputPass'];

    $access = block('SELECT * FROM logins WHERE username = :user',
              array('user' => $username)
                        ,$conn);
    
    foreach ($access as $data) {
    if ( validate_user_creds($username, $password, $category, $data) ){
        switch ($category) {
            case 'guard':
            $_SESSION['user1'] = $username;
            $_SESSION['type'] = $category;
            header("Location: guards/home.php");
                break;

            case 'warden':
            $_SESSION['user2'] = $username;
            $_SESSION['type'] = $category;
            header("Location: warden/home.php");
                break;

            default:
            $status = "Type Of User Not Defined";
            $css_class = "alert-danger";
                break;
        }
    }else {
            $status = "Incorrect LogIn Credentials";
            $css_class = "alert-danger";
        }
    }
}
?> 
 
<body class="left-menu">    
    <div class="menu-wrapper">
        <div class="mobile-menu">
            <nav class="navbar navbar-inverse">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <img src="inc/images/gok.gif" alt="" style="height: 50px; width: 50px;margin-left: 20px;">
                    </div>
                    <div id="navbar" class="navbar-collapse collapse">
                        <ul class="nav navbar-nav">
                            <li class="dropdown">
                                <a href="visitors.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Visitation Requests</a>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="modal" role="button" aria-haspopup="true" aria-expanded="false" data-target="#myModal">Log In</a>
                            </li>
                            <li class="dropdown">
                                <a href="search.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Search Inmate Record &nbsp;&nbsp;<span class="fa fa-search"></span></a>
                            </li>
                        </ul>
                    </div><!--/.nav-collapse -->
                </div><!--/.container-fluid -->
            </nav>
        </div><!-- end mobile-menu -->

        <header class="vertical-header">
            <div class="vertical-header-wrapper">
                <nav class="nav-menu">
                    <div class="logo">
                        <a href="#"><img src="inc/images/gok.gif" alt="" style="width: 180px; height: 180px; margin-top: -32%"></a>
                    </div><!-- end logo -->

                    <div class="margin-block"></div>

                    <ul class="primary-menu">
                        <li class="child-menu"><a href="visitors.php">Visitation Request<i class="fa fa-angle-right"></i></a>
                        </li>
                        <li class="child-menu"><a href="#" data-toggle="modal" data-target="#myModal">Log In <i class="fa fa-angle-right"></i></a>
                        </li>
                        <li class="child-menu"><a href="search.php">Search Inmate Record &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-search"></i></a>
                        </li>
                    </ul>
                    
                    <div class="margin-block"></div>
                    <div class="margin-block"></div>

                    <div class="menu-social">
                        <ul class="list-inline text-center">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                    </div><!-- end menu -->
                </nav><!-- end nav-menu -->
            </div><!-- end vertical-header-wrapper -->
        </header><!-- end header -->
    </div><!-- end menu-wrapper -->

    <div id="wrapper">

        <div class="sectn">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="tagline-message">
                                <img src="inc/images/banner.jpg" style="max-width: 100%">
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end section -->
            
        <?php if (isset($status)) : ?>
            <div class="alert <?php echo $css_class; ?>" style="text-align: center;">
                 <?php echo $status; ?>
            </div>
        <?php endif; ?>

        <section class="section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="text-widget">

                            <p style="text-align: center; color: black; margin-top: -5%;font-family: 'Times New Roman', Times, serif;">The Kenya Prisons Service is a Department in the Ministry of Interior and Coordination of National Government. It contributes to public safety and security by ensuring there is safe custody of all persons who are lawfully committed to prison facilities, as well as facilitating the rehabilitation of custodial sentenced offenders for community reintegration.</p> 

                            <div class="clearfix"></div>

                            <div class="row">
                                <p style="text-align: center; color: black; font-family: 'Times New Roman', Times, serif;"><u> DIRECTORATES </u></p>
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 first">
                                    <ul class="check">
                                        <li><a href="http://www.prisons.go.ke/Administration.php">
                                            Directorate of Administration
                                        </a></li>
                                        <li><a href="http://www.prisons.go.ke/Operation.php">
                                            Directorate of Operations
                                        </a></li>
                            <li><a href="http://www.prisons.go.ke/inspectionsComplainsMonitoringandevaluation.php">
                                            Directorate of Inspections
                                        </a></li>
                                        <li><a href="http://www.prisons.go.ke/Directorate-of-prisons-enterprises">
                                            Directorate of Prisons Enterprises
                                        </a></li>
                                    </ul><!-- end check -->
                                </div><!-- end col-lg-4 -->
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                    <ul class="check">
                                <li><a href="http://www.prisons.go.ke/Commandant-prisons-staff-training-college.php">
                                            Commandant Prisons Staff Training College
                                        </a></li>
                                <li><a href="http://www.prisons.go.ke/Directorate-of-prisons-health-services.php">
                                            Directorate of Prisons Health Services
                                        </a></li>
                                <li><a href="http://www.prisons.go.ke/Directorate-planning-and-development.php">
                                            Directorate Planning and Development
                                        </a></li>
                                <li><a href="http://www.prisons.go.ke/Public-relations-office-and-training.php">
                                            Public Relations Office and Training
                                        </a></li>
                                    </ul><!-- end check -->    
                                </div><!-- end col-lg-4 -->
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 last">
                                    <ul class="check">
                                <li><a href="http://www.prisons.go.ke/Directorate-gender-and-NGO-coordination.php">
                                            Directorate Gender and NGO Coordination
                                        </a></li>
                                        <li><a href="http://www.prisons.go.ke/Administrative-secretary.php">
                                            Administrative Secretary
                                        </a></li>
                        <li><a href="http://www.prisons.go.ke/Directorate-research-statistics-and-legal-unit.php">
                                            Directorate Research, Statistics and Legal Unit
                                        </a></li>
                                    </ul><!-- end check -->
                                </div><!-- end col-lg-4 --> 
                            </div><!-- end row -->      
                        </div><!-- end widget -->
                    </div><!-- end col-lg-6 -->
                </div><!-- end row -->
            </div><!-- end container -->
        </section>

        <section class="section" style="margin-top: -15%;">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4">
                    </div><!-- end col-lg-2 -->
                    <div class="col-lg-4 col-md-4" style="font-family: 'Times New Roman', Times, serif;">
                        <p style="font-size: 20px; text-align: center; font-family: 'Times New Roman', Times, serif; color: black;">Services</p>
                        <ul class="check">
                        <li><a href="http://www.hudumakenya.go.ke/">Huduma Centre</a></li>
                        <li><a href="https://www.ecitizen.go.ke/">E-Citizen</a></li>
                        </ul><!-- end check -->
                    </div><!-- end col-lg-6 -->
                    <div class="col-lg-4 col-md-4">
                    </div><!-- end col-lg-2 -->
                </div><!-- end row -->

                <div class="row">
                    <div class="col-lg-4 col-md-4">
                        <h1 style="font-family: 'Times New Roman', Times, serif; font-size: 20px;">Contact info</h1>
                        <p style="color: black; font-family: 'Times New Roman', Times, serif;">
                            Kenya Prison Headquarters.<br>
                            Bishop Road Upperhill<br> 
                            Next to NSSF Building.<br>
                            P. O. Box 30175 -00100,
                            Nairobi.<br>
                            Tel : 020 2722902

                            E-mail: commissioner.prisons@gmail.com
                        </p>
                    </div><!-- end col-lg-6 -->
                    <div class="col-lg-8 col-md-8">
                    </div><!-- end col-lg-2 -->
                </div><!-- end row -->
                </div>
            </div><!-- end container -->
        </section>

        <div class="section copyrights">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-3">
                            <img src="inc/images/gok.gif" alt="" style="height: 50px; width: 50px;">
                    </div>
                    <div class="col-lg-9 col-md-9 text-right">
                        <div class="cop-links">
                            <ul class="list-inline">
                                <li>&copy; 2019 Kenya Prison's Info System | Designer: <a href="#">Dr~K</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- end wrapper -->

    <!-- LogIn Modal -->
<div id="myModal"  class="modal fade" role="dialog" style="max-width: 100%;">
  <div class="modal-dialog" style="margin-top: 50px; width: 30%;">
    <div class="modal-content">
    <div class="loginbox">
        <div class="modal-body">
         <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h1 style="text-align: center;font-size: 20px;"><i>Welcome Sign In</i></h1>
            <br>
        <form method="POST">
            <!--Category selection-->
         <div class="form-group has-success">
            <label class="control-label col-xs-3" for="cat"></label>
            <div class="col-xs-8">
            <select class="form-control" id="cat" name="cat">
              <option disabled selected>Choose Your Category:</option>
              <option value="guard">Guard</option>
              <option value="warden">Warden</option>
            </select>
        </div>
        </div>

        <div class="form-group has-success">
             <!--username-->
        <label for="inputName" class="control-label">Username:</label>
        <input type="text" class="form-control" name="inputUname" placeholder="Enter Username" required data-error="Please Enter Username">
        <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
        <br>
             <!--password-->
        <label for="inputPass" class="control-label">Password:</label>
        <input type="password" class="form-control" name="inputPass" placeholder="Enter Password" required data-error="Please Enter Password">
        <span class="glyphicon form-control-feedback" aria-hidden="true"></span><br>
        
         <button style="border-radius: 20px; width: 70%; margin: 0px 50px;" type="submit" class="btn btn-success" name="login">Log IN</button><br>
         <br> 
        <!-- <a href="#" style="font-size: 14px; line-height: 20px; color: green;">Don't have an account?</a><br> -->

      </div>
        </form>
        </div>
        
        </div>
            
    </div>

  </div>
</div> 

<?php 
include'footr.php';
?> 
