
    <!-- jQuery Files -->
    <script src="inc/js/jquery.min.js"></script>
    <script src="inc/js/bootstrap.min.js"></script>
    <script src="inc/js/carousel.js"></script>
    <script src="inc/js/parallax.js"></script>
    <script src="inc/js/rotate.js"></script>
    <script src="inc/js/custom.js"></script>
    <script src="inc/js/masonry.js"></script>
    <script src="inc/js/masonry-4-col.js"></script>
	
	<script type="text/javascript">
	    // Material Select Initialization
	$(document).ready(function() {
	$('.mdb-select').materialSelect();
	});
	</script>

</body>
</html>