
<?php 
include'headr.php';
?> 
 
<body class="left-menu">    
    <div class="menu-wrapper">
        <div class="mobile-menu">
            <nav class="navbar navbar-inverse">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="index.html"><img src="inc/images/logo-normal.png" alt=""></a>
                    </div>
                    <div id="navbar" class="navbar-collapse collapse">
                        <ul class="nav navbar-nav">
                            <li class="dropdown">
                                <a href="login.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Home<span class="fa fa-angle-down"></span></a>
                            </li>
                        </ul>
                    </div><!--/.nav-collapse -->
                </div><!--/.container-fluid -->
            </nav>
        </div><!-- end mobile-menu -->

        <header class="vertical-header">
            <div class="vertical-header-wrapper">
                <nav class="nav-menu">
                    <div class="logo">
                        <a href="#"><img src="inc/images/gok.gif" alt="" style="width: 180px; height: 180px; margin-top: -32%"></a>
                    </div><!-- end logo -->

                    <div class="margin-block"></div>

                    <ul class="primary-menu">
                        <li class="child-menu"><a href="login.php">Home<i class="fa fa-angle-right"></i></a>
                        </li>
                    </ul>
                    
                    <div class="margin-block"></div>

                    <div class="margin-block"></div>

                    <div class="menu-social">
                        <ul class="list-inline text-center">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                    </div><!-- end menu -->
                </nav><!-- end nav-menu -->
            </div><!-- end vertical-header-wrapper -->
        </header><!-- end header -->
    </div><!-- end menu-wrapper -->

    <div id="wrapper">

        <div class="sectn">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="tagline-message">
                                <img src="inc/images/banner.jpg" style="max-width: 100%">
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end section -->

        <<section class="section">
            <div class="container">
                <div class="row">
                    <!-- Search form -->
                            <div class="col-lg-3 col-md-12"></div>

                            <?php
                              $output  = "";
                              $output2 = "";
                              if (isset($_POST['such'])){
                                $output = $_POST['search'];

                $runn = $conn->prepare('SELECT * FROM inmates WHERE fname LIKE :first or sname LIKE :second');
                        $runn->execute(array('first' => $output . '%',
                                             'second' => $output . '%' ));
                                 while ($result = $runn->fetch()){
                                                  $first = $result['fname'];
                                                  $second= $result['sname'];

                                            $output2 .= '<div>'.$first.' '.$second.'</div>';
                              
                              }
                                }
                            ?>
                            <form method="POST" action="search.php">
                            <div class="col-lg-6 active-cyan-3 active-cyan-4 mb-4">
                              <input class="form-control" type="text" name="search" placeholder="Search First Or Last Name" aria-label="Search" style=""><i class="glyphicon glyphicon-search" style="position: absolute;  padding: 10px; cursor: pointer; pointer-events: none; right: 20px;"></i>
                              <button type="submit" name="such" style="display: none;"></button>
                            <?php print($output2);?>
                            </div>
                            </form>

                            <div class="col-lg-3 col-md-12"></div>

                            <div class="margin-block"></div>
                            <div class="margin-block"></div>

                    <div class="col-lg-12 col-md-12">
                        <div class="text-widget">
                            <h3 style="text-align: center; font-style: italic; font-family: 'Courier New', Courier, monospace;">Search Results</h3>
                            <?php
                              $output  = "";
                              $row  = "";
                              $num = "";
                              if (isset($_POST['such'])){
                                $output = $_POST['search'];

                                $row = block('SELECT * FROM inmates WHERE fname LIKE :first or sname LIKE :second',
                                      array('first' => $output . '%',
                                            'second' => $output . '%' ),$conn);
                            $num = count($row);
                            }


                            if ($num == 1 && $row ) :
                             foreach ($row as $info) {
                            ?>

                            <div class="col-md-3 text-center">
                            <label for="imag">Inmate Photo</label>
                            <img src="guards/img_upload/<?php echo($info['img_name']);?>" style="max-width: 100%; border-radius: 50%; display: block;" id="imagDisplay">
                             </div><!-- end col -->

                            <div class="col-md-9"> 
                            <div class="container">
                               </br>
                                     <form class="form-horizontal">
                                         <div class="form-group">
                                            <label class="control-label col-xs-3" for="firstName">First Name:</label>
                                             <div class="col-xs-9">
                                <input type="text" class="form-control" id="firstName" placeholder="First Name" value="<?php echo $info['fname'];?>">
                                         </div>
                                         </div>

                                         <div class="form-group">
                                             <label class="control-label col-xs-3" for="lastName">Last Name:</label>
                                             <div class="col-xs-9">
                    <input type="text" class="form-control" id="lastName" value="<?php echo $info['sname'];?>">
                                         </div>
                                          </div>

                            <div class="form-group">
                              <label class="control-label col-xs-3" for="b_date">D.O.B:</label>
                                <div class="col-xs-4">
                    <input type="text" class="form-control" id="b_date" value="<?php echo $info['birth_date'];?>">
                                </div>
                            </div>

                            <div class="form-group">
                              <label class="control-label col-xs-3" for="a_date">Confined On:</label>
                                <div class="col-xs-4">
                <input type="text" class="form-control" id="a_date" value="<?php echo $info['admission_day'];?>">
                                </div>
                            </div>

                              <div class="form-group">
                                   <label class="control-label col-xs-3" for="idNumber">ID Number:</label>
                                   <div class="col-xs-9">
                                    <input type="text" class="form-control" name="idNum" id="idNumber" value="<?php echo $info['id_number'];?>">
                                   </div>
                              </div>

                            <div class="form-group">
                                <label class="control-label col-xs-3" for="sentc">Sentence:</label>
                                <div class="col-xs-9">
                                    <input type="text" class="form-control" name="cent" id="sentc" value="<?php echo $info['sentence'];?>">
                                </div>
                              </div>

                            <div class="form-group">
                                <label class="control-label col-xs-3">Gender:</label>
                                <div class="col-xs-6">
                            <input type="text" class="form-control" id="gend" value="<?php echo $info['gender'];?>">
                                </div>
                            </div>

                                     <div class="form-group">
                                          <div class="col-xs-offset-3 col-xs-9">
                                          <input type="reset" class="btn btn-success" value="Reset" style="background-color: #4CAF50; color: white; cursor: pointer; border-radius: 20px;">
                                          </div>
                                          </div>
                                     </div>
                                     </form>
                               </div>
                            </div>

                            <?php } endif; ?>

                            <div class="clearfix"></div>     
                        </div><!-- end widget -->
                    </div><!-- end col-lg-6 -->
                </div><!-- end row -->
            </div><!-- end container -->
        </section>
                    <div class="margin-block"></div>


        <div class="section copyrights">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-3">
                            <img src="inc/images/gok.gif" alt="" style="height: 50px; width: 50px;">
                    </div>
                    <div class="col-lg-9 col-md-9 text-right">
                        <div class="cop-links">
                            <ul class="list-inline">
                                <li>&copy; 2019 Kenya Prison's Info System | Designer: <a href="#">Dr~K</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- end wrapper -->

<?php 
include'footr.php';
?> 