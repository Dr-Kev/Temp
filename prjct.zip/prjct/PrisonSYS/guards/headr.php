<?php
session_start();

include '../functions/config.php';
include '../functions/functions.php';
include '../functions/db.php';

if (!is_logged_in($_SESSION['user1'])){
    header("Location: ../index.php");
    die();
}

?>

<!doctype html>
<html class="no-js" lang="en"> 
<head>

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <!-- Mobile Meta -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    
    <!-- Site Meta -->
    <title>PRISON SYSTEM</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    
    <!-- Site Icons -->
    <link rel="shortcut icon" href="inc/images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="inc/images/apple-touch-icon.png">

	<!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet"> 

    <!-- Scripts -->
    <script type="text/javascript" src="inc/js/jquery.min.js"></script>
    <script type="text/javascript" src="inc/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="inc/js/custom.js"></script>
    <script type="text/javascript" src="lib/bootstrap-datepicker.js"></script>


	<!-- Custom & Default Styles -->
	<link rel="stylesheet" type="text/css" href="inc/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="inc/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="lib/bootstrap-datepicker.css">
    <link rel="stylesheet" type="text/css" href="inc/style1.css">
    <link rel="stylesheet" href="lib/bootstrap-select.css"/>
</head>
    
<body class="left-menu" style="background-color: #ffffff; color: #0d0c0c; font-size: 16px; line-height: 1.6; font-family: 'Times New Roman', 'Times', 'serif';">    
    <div class="menu-wrapper">
        <div class="mobile-menu">
            <nav class="navbar navbar-inverse">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <img src="inc/images/gok.gif" alt="" style="height: 50px; width: 50px;margin-left: 20px;">
                    </div>
                    <div id="navbar" class="navbar-collapse collapse">
                        <ul class="nav navbar-nav">
                            <li class="dropdown">
                                <a href="home.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Home </span></a>
                            </li>
                            <li class="dropdown">
                                <a href="visits.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Visitation Requests</a>
                            </li>
                            <li class="dropdown">
                                <a href="search.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Search Inmate Record &nbsp;&nbsp;<span class="fa fa-search"></span></a>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Inmates <span class="fa fa-angle-down"></span></a>
                                <ul class="dropdown-menu">
                                    <li><a href="register.php">Register Inmate Records</a></li>
                                    <li><a href="inmateView.php">View Inmate Records</a></li>
                                    <li><a href="work.php">Inmate Work Records</a></li>
                                    <li><a href="medical.php">Inmate Medical Records</a></li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Reports <span class="fa fa-angle-down"></span></a>
                                <ul class="dropdown-menu">
                                    <li><a href="daily.php">Daily report records</a></li>
                                    <li><a href="monthly.php">Monthly report records</a></li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="logout.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Logout&nbsp;</a>
                            </li>
                        </ul>
                    </div><!--/.nav-collapse -->
                </div><!--/.container-fluid -->
            </nav>
        </div><!-- end mobile-menu -->

        <header class="vertical-header">
            <div class="vertical-header-wrapper">
                <nav class="nav-menu">
                    <div class="logo">
                        <a href="#"><img src="inc/images/gok.gif" alt="" style="width: 180px; height: 180px; margin-top: -32%"></a>
                    </div><!-- end logo -->

                    <div class="margin-block"></div>

                    <ul class="primary-menu">
                        <li class="child-menu"><a href="home.php">Home</i></a>
                        </li>
                        <li class="child-menu"><a href="visits.php">Visitation Requests</i></a></li>
                        <li class="child-menu"><a href="search.php">Search Inmate Record &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-search"></i></a>
                        </li>
                        <li class="child-menu"><a href="#">Inmates <i class="fa fa-angle-right"></i></a>
                            <div class="sub-menu-wrapper">
                                <ul class="sub-menu center-content">
                                    <li><a href="register.php">Register Inmate Records</a></li>
                                    <li><a href="inmateView.php">View Inmate Records</a></li>
                                    <li><a href="work.php">Inmate Work Records</a></li>
                                    <li><a href="medical.php">Inmate Medical Records</a></li>
                                </ul>
                            </div>
                        </li>

                        <li class="child-menu"><a href="#">Reports <i class="fa fa-angle-right"></i></a>
                            <div class="sub-menu-wrapper">
                                <ul class="sub-menu center-content">
                                    <li><a href="daily.php">Daily report records</a></li>
                                    <li><a href="monthly.php">Monthly report records</a></li>
                                </ul>
                            </div>
                        </li>
                        <li class="child-menu"><a href="logout.php">Logout</i></a>
                        </li>
                    </ul>
                    
                    <div class="margin-block"></div>
                    <div class="margin-block"></div>

                    <div class="menu-social">
                        <ul class="list-inline text-center">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                    </div><!-- end menu -->
                </nav><!-- end nav-menu -->
            </div><!-- end vertical-header-wrapper -->
        </header><!-- end header -->
    </div><!-- end menu-wrapper -->