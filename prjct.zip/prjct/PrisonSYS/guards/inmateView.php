
<?php 
include'headr.php';

?> 

    <div id="wrapper">

        <div class="sectin">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="tagline-message">
                            <img src="inc/images/banner.jpg" style="max-width: 100%">
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end section -->

        <section class="section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="text-widget">
                            <h3 style="text-align: left; margin-top: -80px; font-size: 18px; font-family:'Courier New', Courier, monospace;">
                            Inmate Records:
                            </h3>

                            <div class="panel-group" id="accordion1">
                            <div class="panel panel-info">
                              <div class="panel-heading">
                                <h4 class="panel-title">
                                  <a data-toggle="collapse" data-parent="#accordion1" href="#collapseOne" style="color: green; text-decoration: none;">
                                    Block A
                                  </a>
                                </h4>
                              </div>
                              <div id="collapseOne" class="panel-collapse collapse">
                                <div class="panel-body">
                                    <div class="table-responsive">
                                    <table class="table table-hover">
                                    <thead style="background-color: darkgrey;">
                                      <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Names</th>
                                        <th scope="col">Sentence</th>
                                        <th scope="col">Block</th>
                                        <th scope="col">Cell Number</th>
                                        <th scope="col">Details</th>
                                      </tr>
                                    </thead>

                          <?php 
                          if ($conn){
                            $data = block("SELECT * FROM inmates WHERE block = :letter",
                                              array('letter' => 'A'),
                                              $conn);  

                             } else die('Could Not Connect');

                          if ($data) : 
                             $i=1;
                             foreach ($data as $info) {?>
                                    <tbody>

                                      <tr>
                                      <th scope="row"> <?php echo $i;  $i++;?></th>
                                      <td> <?php echo $info['fname']." ".$info['sname'];?></td>
                                      <td> <?php echo $info['sentence'];?></td>
                                      <td> <?php echo $info['block'];?></td>
                                      <td> <?php echo $info['cell_No'];?></td>
                                      <td>
                                    <a href="#" data-toggle="modal" data-target="#modalview">
                                        <input type="button" value="More" style="background-color: #4CAF50; color: white; cursor: pointer; border-radius: 20px;">
                                    </a>
                                      </td>
                                    </tr>

                                    </tbody>

                            <?php } endif; ?>

                                  </table>
                                </div>
                                </div>
                              </div>
                            </div>

                            <div class="margin-block"></div>

                            <div class="panel-group" id="accordion2">
                            <div class="panel panel-info">
                              <div class="panel-heading">
                                <h4 class="panel-title">
                                  <a data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo" style="color: green; text-decoration: none;">
                                    Block B
                                  </a>
                                </h4>
                              </div>
                              <div id="collapseTwo" class="panel-collapse collapse">
                                <div class="panel-body">
                                    <div class="table-responsive">
                                    <table class="table table-hover">
                                    <thead style="background-color: darkgrey;">
                                      <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Names</th>
                                        <th scope="col">Sentence</th>
                                        <th scope="col">Block</th>
                                        <th scope="col">Cell Number</th>
                                        <th scope="col">Details</th>
                                      </tr>
                                    </thead>

                          <?php 
                          if ($conn){
                            $data = block("SELECT * FROM inmates WHERE block = :letter",
                                              array('letter' => 'B'),
                                              $conn);  

                             } else die('Could Not Connect');

                          if ($data) : 
                             $i=1;
                             foreach ($data as $info) {?>
                                    <tbody>

                                      <tr>
                                      <th scope="row"> <?php echo $i;  $i++;?></th>
                                      <td> <?php echo $info['fname']." ".$info['sname'];?></td>
                                      <td> <?php echo $info['sentence'];?></td>
                                      <td> <?php echo $info['block'];?></td>
                                      <td> <?php echo $info['cell_No'];?></td>
                                      <td>
                                    <a href="#" data-toggle="modal" data-target="#modalview">
                                        <input type="button" value="More" style="background-color: #4CAF50; color: white; cursor: pointer; border-radius: 20px;">
                                    </a>
                                      </td>
                                    </tr>

                                    </tbody>

                            <?php } endif; ?>

                                  </table>
                                </div>
                                </div>
                              </div>
                            </div>

                            <div class="margin-block"></div>

                            <div class="panel-group" id="accordion3">
                            <div class="panel panel-info">
                              <div class="panel-heading">
                                <h4 class="panel-title">
                                  <a data-toggle="collapse" data-parent="#accordion3" href="#collapseThree" style="color: green; text-decoration: none;">
                                    Block C
                                  </a>
                                </h4>
                              </div>
                              <div id="collapseThree" class="panel-collapse collapse">
                                <div class="panel-body">
                                    <div class="table-responsive">
                                    <table class="table table-hover">
                                    <thead style="background-color: darkgrey;">
                                      <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Names</th>
                                        <th scope="col">Sentence</th>
                                        <th scope="col">Block</th>
                                        <th scope="col">Cell Number</th>
                                        <th scope="col">Details</th>
                                      </tr>
                                    </thead>

                          <?php 
                          if ($conn){
                            $data = block("SELECT * FROM inmates WHERE block = :letter",
                                              array('letter' => 'C'),
                                              $conn);  

                             } else die('Could Not Connect');

                          if ($data) : 
                             $i=1;
                             foreach ($data as $info) {?>
                                    <tbody>

                                      <tr>
                                      <th scope="row"> <?php echo $i;  $i++;?></th>
                                      <td> <?php echo $info['fname']." ".$info['sname'];?></td>
                                      <td> <?php echo $info['sentence'];?></td>
                                      <td> <?php echo $info['block'];?></td>
                                      <td> <?php echo $info['cell_No'];?></td>
                                      <td>
                                    <a href="#" data-toggle="modal" data-target="#modalview">
                                        <input type="button" value="More" class="viewbtn" style="background-color: #4CAF50; color: white; cursor: pointer; border-radius: 20px;">
                                    </a>
                                      </td>
                                    </tr>

                                    </tbody>

                            <?php } endif; ?>

                                  </table>
                                </div>
                                </div>
                              </div>
                            </div>

                          </div> 
                        </div><!-- end widget -->
                    </div><!-- end col-lg-6 -->
                </div><!-- end row -->
            </div><!-- end container -->
        </section>



        <!-- View Modal -->
<div id="modalview" class="modal fade" role="dialog" style="max-width: 100%;">
  <div class="modal-dialog" style="margin-top: 50px;">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" style="text-align: center; font-style: italic; font-family: 'Courier New', Courier, monospace;">Inmate Details</h4>
      </div>
      <div class="modal-body">
        <form class="form-horizontal" action="" method="get" enctype="multipart/form-data">
          <div class="text-center">
          <img src="inc/images/avatar.png" style="margin-left: 40%; width: 20%; border-radius: 50%; display: block;" id="imagDisplay">
          <input type="file" id="imag" name="imag" style="display: none;">
          <br>
          <label for="imag">Inmate Photo</label>
          </div><!-- end col -->

          <div class="container">                                          
              <div class="form-group">
               <label class="control-label col-xs-3" for="firstName">First Name:</label>
                    <div class="col-xs-9">
                      <input type="text" class="form-control" name="Fname" id="firstName" value="">
                    </div>
              </div>

              <div class="form-group">
                <label class="control-label col-xs-3" for="lastName">Last Name:</label>
                <div class="col-xs-9">
                      <input type="text" class="form-control" name="Sname" id="lastName" value="">
                </div>
              </div>

              <div class="form-group">
                              <label class="control-label col-xs-3" for="offence">Birth Date:</label>
                                <div class="col-xs-3">
                                <input type="text" class="form-control" id="usr1" name="b_date" value="">
                                </div>

                                <label class="control-label col-xs-3" for="offence">Admitted On:</label>
                                <div class="col-xs-3">
                                <input type="text" class="form-control" id="usr1" name="add_date" value="">
                                </div>
               </div>

               <div class="form-group">
                                   <label class="control-label col-xs-3" for="idNumber">ID Number:</label>
                                   <div class="col-xs-9">
                                    <input type="text" class="form-control" name="idNum" id="idNumber" value="">
                                   </div>
                </div>

                 <div class="form-group">
                                <label class="control-label col-xs-3" for="sentc">Sentence:</label>
                                <div class="col-xs-3">
                                    <input type="text" class="form-control" name="cent" id="sentc" value="">
                               </div>

                                   <label class="control-label col-xs-3" for="phoneNumber">Cell No:</label>
                                   <div class="col-xs-3">
                                    <input type="text" class="form-control" name="cell" id="cellNumber" value="">
                                   </div>
                 </div>

                 <div class="form-group">
                                <label class="control-label col-xs-3" for="offence">Offence Committed:</label>
                                <div class="col-xs-3">
                                  <input type="text" class="form-control" name="cell" id="cellNumber" value="">
                                </div>

                                <label class="control-label col-xs-3" for="blocks">Resident Block:</label>
                                <div class="col-xs-3">
                                <input type="text" class="form-control" name="cell" id="cellNumber" value="">
                                </div>
                </div>

                 <div class="form-group">
                                <label class="control-label col-xs-3">Gender:</label>
                                <div class="col-xs-9">
                                  <input type="text" class="form-control" name="cell" id="cellNumber" value="">
                                </div>
                 </div>

                 <br>
                   <div class="form-group">
                                <div class="col-xs-offset-5 col-xs-9">
                                <input type="submit" name="update_user" class="btn btn-primary" value="print">
                                </div>
                  </div>

          </div>
        </form>
      </div>
    </div>

  </div>
</div>
                    <div class="margin-block"></div>
                    <div class="margin-block"></div>
                    <div class="margin-block"></div>

        

<?php 
include'footr.php';
?> 
