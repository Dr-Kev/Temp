 <?php

include '../functions/config.php';
include '../functions/db.php';

if(isset($_POST['update'])) {
  $id = $_POST['update_id'];

  $ti = $_POST['Wtitle'];
  $des = $_POST['Wdesc'];
  $inm = $_POST['Winm'];
  $per = $_POST['Wperf'];

  registry("UPDATE work SET title=:tit, description=:dec, inmate_assigned =:inmate, review=:rev WHERE work_id =:id",
              array('id' => $id,
                    'tit' => $ti,
                    'dec' => $des,
                    'inmate' => $inm,
                    'rev' => $per) ,$conn);
  header('Location:work.php');
}

if(isset($_POST['update_user'])) {
  $id = $_POST['update_id'];

  $first = $_POST['Fname'];
  $second= $_POST['Sname'];
  $bDay= $_POST['b_date'];
  $aDay= $_POST['add_date'];
  $cel= $_POST['cell'];
  $off= $_POST['offnc'];
  $blok= $_POST['bloc'];
  $gend= $_POST['genderRadios'];
  $idd= $_POST['idNum'];
  $sent= $_POST['cent'];

  $imge = file_get_contents($_FILES['imag']['tmp_name']);
  $img_nme = $_FILES['imag']['name'];
  $target = 'img_upload/' . $img_nme;

  move_uploaded_file($_FILES['imag']['tmp_name'], $target);

  registry("UPDATE inmates SET img_name=:img_name, image=:image, fname=:fname, sname=:sname, cell_No=:cell, 
    block=:blck, sentence=:snt, offence=:offence, birth_date=:birth, admission_day=:admission, 
    gender=:gender,id_number=:id)", array('img_name' => $img_nme,
                    'image' => $imge,
                    'fname' => $first,
                    'sname' => $second,
                    'cell' => $cel,
                    'blck' => $blok,
                    'snt' => $sent,
                    'offence' => $off,
                    'birth' => $bDay,
                    'admission' => $aDay,
                    'gender' => $gend,
                    'id' => $idd ), $conn);

  header('Location:inmateView.php');
}

  ?>
     